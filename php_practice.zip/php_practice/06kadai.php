<?php
function times2($num){
 return  $num *2;
  }
echo times2(100);

function product($arr){
$a = array(1,3,5,7,9);
$result = $a[0];
for($i = 1;$i <count ($a);$i++){
 $result *= $a[$i];
}
return $result;
}
echo product(array(1,3,5,7,9));

function max_array($arr){
  $max_number = $arr[0];
  foreach($arr as $a){
   if($max_number < $a){
    $max_number = $a;
   }
  }

  return $max_number;
}
echo max_array(1,3,5,7);

$htmlremovestr = strip_tags($htmlstr);

$members  = array(1,2,3);
array_push ($members,4,5);
print_r(($members));

$timestamp = mktime (0,0,0,8,1,2017);
echo $timestamp;

echo date('Y-m-d')."<br/>\n";


