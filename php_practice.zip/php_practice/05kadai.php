<?php
$name = "naoki";
if ("naoki"){
    echo "私はあなたの名前です";
}else{echo "私はあなたの名前ではありません";}

$total = 0;
for($i = 0; $i <= 10000;$i++){
    $total += $i;}
echo $total;

$furuits = array("apple","orange","banana","grape","strawberry");
foreach($furuits as $furuit){
    echo  $furuit;
}

$start = 1;

$end = 100;

for($i = $start; $i <= $end; $i++)
if($i % 5 == 0){
    echo $i;
  }