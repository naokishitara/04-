<?php
$a = 3;
$b = 7;
echo $a + $b
